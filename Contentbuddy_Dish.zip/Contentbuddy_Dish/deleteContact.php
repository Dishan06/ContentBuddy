<?php

//check the userID and saving it
if(isset($_GET['ID'])){	
$ID=$_GET['ID'];	
}



	
//database connection	
include('inc/database.php');

//query
 $sql="DELETE FROM contact WHERE ID = $ID"	;

//storing the results in variable
	$result=mysqli_query($conn,$sql);



//display message according to results	
	if($result){
	

	
	header('location:index.php');	
		
		
	}else{
		?>

		<script>
				alert("Something went wrong");
				window.location="index.php";
        </script>
		
	<?php	
	}
	
	
	
	
	
//close connection
mysqli_close($conn);

?>