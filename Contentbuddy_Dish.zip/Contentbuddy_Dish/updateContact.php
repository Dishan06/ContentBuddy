<?php

//store the values got from edit contact page
if(isset($_POST['ID'])){	
$ID=$_POST['ID'];	
}

if(isset($_POST['mobile_number'])){	
$mobile_number=$_POST['mobile_number'];	
}

if(isset($_POST['user_name'])){	
$user_name=$_POST['user_name'];	
}

if(isset($_POST['email'])){	
$email=$_POST['email'];	
}
	
//creating the database connection	
include('inc/database.php');

//sql query
 $sql="update contact set ID='$ID' , user_name='$user_name', email='$email', mobile_number='$mobile_number' WHERE ID='$ID'"	;

//stroing the result in variable
	$result=mysqli_query($conn,$sql);



//Popup alert result message
	if($result){
	?>
	<script>
				alert("Successfully Updated");
				window.location="index.php";
        </script>
	
	
	<?php	
		
	}else{
		?>

		<script>
				alert("Something went wrong");
				window.location="index.php";
        </script>
		
	<?php	
	}
	
	
	
	
	
//close database connection
mysqli_close($conn);
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	











?>