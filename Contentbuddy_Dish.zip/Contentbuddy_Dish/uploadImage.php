<?php 
//including the header
include('inc/head.php');



?>
<!--form to input the image-->
<body>
    <form action ="upload.php" method ="post" enctype="multipart/form-data" class="image-form">
        <input type="file" name="my_image" >
        <input type="submit" name="submit" value="Upload">
    </form>
</body>
</html>
