<?php include('inc/head.php');?>


  <body >
	 <?php
	  
	  if(isset($_GET['ID'])){
		  $ID=$_GET['ID'];
	  } 
	  ?> 
	
	  
	  
	  
	  <section class="container-fluid" style=";margin-top: 50px">
	  
		  
		  
		  
		  
		  
    <h1 class="jumbotron" align = "center" style = "background-color: #abf; color: #fff">Edit Contact</h1>
	  </section>
	  
	  
	<section class="container table-responsive" style="min-height: 400px;"> 
	<?php 
	  include('inc/database.php'); 
	  
	  
 $sql="SELECT  * from contact where ID=$ID limit 1 "	;


	$result=mysqli_query($conn,$sql);
	
	$no=mysqli_num_rows($result);
	
	if($no>0){
		
		
		?>
		
		<form action="updateContact.php" id="myForm" method="post">
	  <table class="table table-bordered table-hover " >
		  
		 
		  
		 
	  
	  <?php
		$no=0;
	while( $row=mysqli_fetch_assoc($result))	{
		$no++;
		?>
		
		  
		<tr>
			<td>NAME</td>
		  <td> <input name="ID" type="hidden" value="<?php echo $row['ID']; ?>"  />
			  <input name="user_name" type="text" value="<?php echo $row['user_name']; ?>"  class="form-control"/></td>
		  </tr>	
			
			<tr>
			<td>CONTACT NUMBER</td>	
		  <td><input name="mobile_number" type="text" value="<?php echo $row['mobile_number']; ?>" class="form-control"/></td>
		  </tr>	
			<tr>
			 <td>EMAIL</td>	
			<td><input name="email" type="email" value="<?php echo $row['email']; ?>" class="form-control"/></td>
		  </tr>	
	<?php	
	}
	 
	?>
		  
	</table>	
		</form>	
	<?php  
	}
	  
	 
	  ?>
	 
		
		<button form="myForm" type="submit" class="btn btn-primary pull-right" data-toggle="modal" data-target="#saveContactModal"> <span class="glyphicon glyphicon-plus"></span> Update</button>
		
		
</section>  	  
	  
	  
	  
	  
	  
	  
 <?php include('inc/footer.php'); ?>	 

 <?php include('inc/scripts.php'); ?>	
	  
<?php include('inc/allModals.php'); ?>

	<script>
	  function getConfirmation(){
		  var x=confirm("YOU CONFIRM THE CHANGES?");
		  
		  if(x==true){
			  return true;
		  }else{
			return false;  
		  }
		  
		  
	  }
	  
	  
	  </script>  
	  
	  
	  
	  
	
	  
	  
	  
  </body>


</html>