<section class="container-fluid ">
	  <div class="row myFooter" style="background-color:#fff;color:#abf">
		   <div class="col-sm-4"><p>Developed by Thayaparan Dishan (K2284686)</p></div>

		</div>
	  
	</section> 


