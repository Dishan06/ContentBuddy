<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Contact Buddy</title>

    <!-- Adding the bootstrap css-->
    <link rel="stylesheet" href="css/bootstrap.min.css" >
	  
	   <!-- Adding the customized CSS-->
    <link rel="stylesheet" href="css/main.css">
	  
  </head>