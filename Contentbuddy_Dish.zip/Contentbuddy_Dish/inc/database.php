<?php

$conn=mysqli_connect("localhost","id20016526_contectbuddy","jb7CYheWvTyH{Mdn","id20016526_contect");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }


?>